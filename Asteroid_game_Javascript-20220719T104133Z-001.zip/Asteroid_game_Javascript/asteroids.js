"use strict";
function generateAsteriods(size1, ast, x, y, g, aList) {
    const svg = document.getElementById("canvas");
    const transformMatrix = (e) => new WebKitCSSMatrix(window.getComputedStyle(e.elem).webkitTransform);
    let asteroid1 = new Elem(svg, 'circle', ast.elem)
        .attr("r", String(size1))
        .attr("fill", "white")
        .attr('visibility', 'visible')
        .attr("cx", x)
        .attr("cy", y);
    aList.push(asteroid1);
    const r1 = Math.floor(Math.random() * (+20 - -20)) + -20;
    const r2 = Math.floor(Math.random() * (+20 - -20)) + -20;
    Observable.interval(100)
        .subscribe(() => {
        (Number(asteroid1.attr('cx')) < 0) ?
            asteroid1
                .attr('cx', String(600))
                .attr('cy', String(r2 + Number(asteroid1.attr('cy')))) : asteroid1;
        (Number(asteroid1.attr('cx')) > 600) ?
            asteroid1
                .attr('cx', String(0))
                .attr('cy', String(r2 + Number(asteroid1.attr('cy')))) : asteroid1;
        (Number(asteroid1.attr('cy')) > 600) ?
            asteroid1
                .attr('cx', String(r1 + Number(asteroid1.attr('cx'))))
                .attr('cy', String(0)) : asteroid1;
        (Number(asteroid1.attr('cy')) < 0) ?
            asteroid1
                .attr('cx', String(r1 + Number(asteroid1.attr('cx'))))
                .attr('cy', String(600)) : asteroid1;
        asteroid1
            .attr('cx', String(r1 + Number(asteroid1.attr('cx'))))
            .attr('cy', String(r2 + Number(asteroid1.attr('cy'))));
        const difference_in_y = transformMatrix(g).m42 - Number(asteroid1.attr("cy"));
        const difference_in_x = transformMatrix(g).m41 - Number(asteroid1.attr("cx"));
        const distance = Math.sqrt((difference_in_y * difference_in_y) + (difference_in_x * difference_in_x));
        if (distance <= Number(asteroid1.attr("r")) && asteroid1.attr("visibility") != "hidden") {
            let rec2 = new Elem(svg, "rect")
                .attr("width", "4000")
                .attr("height", "4000")
                .attr("x", 0)
                .attr("y", 0)
                .attr("fill", "black");
            let endgame = new Elem(svg, "text")
                .attr('x', 300)
                .attr('y', 300)
                .attr('fill', 'red')
                .attr('font-size', 50);
            endgame.elem.textContent = "Game Over";
        }
    });
}
function asteroids() {
    const svg = document.getElementById("canvas");
    let rec = new Elem(svg, "rect")
        .attr("width", "1000")
        .attr("height", "1000")
        .attr("x", 0)
        .attr("y", 0)
        .attr("fill", "black");
    var astlist = new Array;
    let g = new Elem(svg, 'g')
        .attr("transform", "translate(300 300) rotate(170)");
    let ship = new Elem(svg, 'polygon', g.elem)
        .attr("points", "-15,20 15,20 0,-20")
        .attr("style", "fill:lime;stroke:purple;stroke-width:1")
        .attr("pointX", "300")
        .attr("pointY", "320");
    const transformMatrix = (e) => new WebKitCSSMatrix(window.getComputedStyle(e.elem).webkitTransform);
    const mousemove = Observable.fromEvent(svg, 'mousemove');
    rec.observe('mousemove')
        .flatMap(({}) => mousemove
        .map(({ clientX, clientY }) => ({ clientX: clientX, clientY: clientY, x: transformMatrix(g).m41, y: transformMatrix(g).m42 })))
        .subscribe(({ clientX, clientY, x, y }) => {
        g.attr("transform", "translate(" + String(x + ((-x + clientX) / 1000)) + "," + String(y + ((-y + clientY) / 1000)) + ") rotate(" + String(Math.atan2(clientX - x, y - clientY) * 180 / Math.PI) + ")");
    });
    let ast = new Elem(svg, 'g');
    Observable.interval(5000)
        .subscribe(() => {
        const n1 = Math.random(), n2 = Math.floor(Math.random() * (+600 - -0)) + -0;
        var size1 = Math.floor(Math.random() * (+50 - +10)) + +10;
        n1 <= 0.25 ? generateAsteriods(size1, ast, String(0), String(n2), g, astlist) :
            (n1 <= 0.5 ? generateAsteriods(size1, ast, String(600), String(n2), g, astlist) :
                (n1 <= 0.75 ? generateAsteriods(size1, ast, String(n2), String(0), g, astlist) :
                    (generateAsteriods(size1, ast, String(n2), String(600), g, astlist))));
    });
    const mouseup = Observable.fromEvent(svg, 'mouseup'), mousedown = Observable.fromEvent(svg, 'mousedown');
    rec.observe('mousedown')
        .flatMap(({}) => mousedown
        .takeUntil(mouseup)
        .map(({ clientX, clientY }) => ({ x: (-transformMatrix(g).m41 + clientX) / 10, y: (-transformMatrix(g).m42 + clientY) / 10 })))
        .subscribe(({ x, y }) => {
        let bullets = new Elem(svg, 'circle')
            .attr("cx", String(transformMatrix(g).m41))
            .attr("cy", String(transformMatrix(g).m42))
            .attr("r", "4")
            .attr("fill", "purple");
        Observable.interval(10)
            .takeUntil(Observable.interval(10000))
            .subscribe(() => {
            bullets.attr("transform", "translate(" + String(x) + " " + String(y) + ")")
                .attr('cx', String(x + Number(bullets.attr("cx"))))
                .attr('cy', String(y + Number(bullets.attr("cy"))));
            (Number(bullets.attr('cx')) < 0 || Number(bullets.attr('cx')) > 600 || Number(bullets.attr('cy')) < 0 || Number(bullets.attr('cy')) > 600) ?
                bullets.elem.remove() : null;
            Observable.fromArray(astlist).subscribe((asteroid) => {
                const difference_in_y = Number(bullets.attr("cy")) - Number(asteroid.attr("cy"));
                const difference_in_x = Number(bullets.attr("cx")) - Number(asteroid.attr("cx"));
                const distance = Math.sqrt((difference_in_y * difference_in_y) + (difference_in_x * difference_in_x));
                var size1 = Math.floor(Math.random() * (+30 - +10)) + +10;
                (distance <= Number(bullets.attr("r")) + Number(asteroid.attr("r"))) ? (astlist.splice(astlist.indexOf(asteroid), 1), ((Number(asteroid.attr("r")) > 30) ? (generateAsteriods(size1, ast, asteroid.attr("cx"), asteroid.attr("cy"), g, astlist),
                    generateAsteriods(size1, ast, asteroid.attr("cx"), asteroid.attr("cy"), g, astlist)) : null),
                    asteroid.attr("visibility", "hidden"),
                    asteroid.elem.remove(),
                    bullets.elem.remove()) : null;
            });
        });
    });
}
if (typeof window != 'undefined')
    window.onload = () => {
        asteroids();
    };
//# sourceMappingURL=asteroids.js.map