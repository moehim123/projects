
class Node1:
    def __init__(self):
        self.array = [-1] * 37 #to account for numbers, letters and $
        self.endNode = []


class Trie:

    def __init__(self):
       self.root = Node1()


    def addWord(self,word,index):

        """""
        Functionality of the function: The function takes care of adding a name or an id
        to the class
        [Time complexity]
        Best: O(T)  is the number of characters in all identi􏰃cation numbers and all last names
        Worst:  O(T)  is the number of characters in all identi􏰃cation numbers and all last names
        [Space complexity]
        Best:O(n) n is the length of the word or the id
        Worst: O(n) n is the length of the word or the id
        Error handle:
        Return: None
        Parameter: the word (which is either an id or a name) and  index
        Precondition: None
        """


        word = word.lower()
        word += '$'
        new_name = False
        current_node = self.root
        for i in word:
            if i == '$':
                if current_node.array[36] == -1:
                    current_node.array[36] = [index] #last index gonna have the array of indexes
                    new_name = True
                else:
                    current_node.array[36].append(index)

            else:
                if ord(i) >= 48 and ord(i) <= 57:
                    if current_node.array[ord(i) - 48+25] == -1:
                        current_node.array[ord(i)- 48+25] = Node1()


                    current_node = current_node.array[ord(i)- 48+25]#///

                else:
                    if current_node.array[ord(i)-97] == -1: #to check if the array in the root has the same letter or its empty then you add a new word
                        current_node.array[ord(i)-97] = Node1()

                    current_node = current_node.array[ord(i)-97]

        #At the end of the loop the current node is gonna be the endNode
        next_current = self.root
        if new_name == True: #so the node wont be added twice
            for j in word:
                next_current.endNode.append(current_node)
                if ord(j) >= 48 and ord(j) <= 57:
                    next_current = next_current.array[ord(j)- 48+25]
                elif j != "$":
                    next_current = next_current.array[ord(j) - 97]




    def searchPrefix(self, prefix):

        """""
        Functionality of the function: This function search the given prefix
        [Time complexity]
        Best: O(n) n is the length of the prefix
        Worst:  O(n) n is the length of the prefix
        [Space complexity]
        Best:O(n)
        Worst: O(n)
        Return: list of indexes of the matching prefixes
        Parameter: prefix, either name prefix  or id prefix
        Precondition: None
        """


        list_of_indexes = []
        current_node = self.root
        for i in prefix:
            if ord(i) >= 48 and ord(i) <= 57:
                if current_node.array[ord(i) - 48+25] != -1:
                    current_node = current_node.array[ord(i) - 48+25]

                else:
                    return []
            else:
                if current_node.array[ord(i) - 97] != -1:
                    current_node = current_node.array[ord(i) - 97]

                else:
                    return []

        # the last index in the array of each $ node it will have a list of the indexes
        for j in  current_node.endNode:
            for k in j.array[36]:
                list_of_indexes.append(k)

        return list_of_indexes



class Node2:
    def __init__(self):
        self.array = [-1] * 27  # to account for letters and $


class Trie2:

    def __init__(self):
        self.root = Node2()

    def reverse(self, word, index):

        """""
        Functionality of the function: The function takes care of looping through the
        word (which is the substrings of the given word) and return a list of the found substrings
        [Time complexity]
        Best: O(n) where n is the length of the word (substring)
        Worst: O(n)  where n is the length of the word (substring)
        [Space complexity]
        Best:O(n)
        Worst: O(n)
        Return: found_match list which has the substrings and the their index
        Parameter: the word and index
        Precondition: None
        """

        current_node = self.root
        found_match = []
        for i in range(len(word)):
            if current_node.array[ord(word[i]) - 97] == -1:
                return found_match
            elif i > 0:
                found_match.append([word[0:i + 1], index])

            current_node = current_node.array[ord(word[i]) - 97]

        return found_match

    def originalWord(self, word, index):

        """""
        Functionality of the function: The function takes care of adding the word
        [Time complexity]
        Best: O(n) where n is the length of the word
        Worst:  O(n) where n is the length of the word
        [Space complexity]
        Best:O(n)
        Worst: O(n)
        Return: None
        Parameter: the word and  index
        Precondition: None
        """

        current_node = self.root
        for i in word:
            if current_node.array[ord(i) - 97] == -1:  # to check if the array in the root has the same letter or its empty then you add a new word
                current_node.array[ord(i) - 97] = Node2()

            current_node = current_node.array[ord(i) - 97]

        # this is to ensure that all the occurences are printed.
        if current_node.array[26] == -1:
            current_node.array[26] = [index]

        else:  # REMOVWE
            current_node.array[26].append(index)

    def addWord2(self, word):

        """""
        Functionality of the function: The function takes care of adding a word
        [Time complexity]
        Best: O(n)
        Worst: O(n)
        [Space complexity]
        Best:O(n)
        Worst: O(n)
        Return: output_list which has the list of substrings and indexes to be printed
        Parameter: the word (which is either an id or a name) and  index
        Precondition: None
        """
        word = word.lower()
        reverse = ""
        for i in range(len(word) - 1, -1, -1):
            reverse += word[i]

        #generate reverse substrings and pass it to reverse function
        for i in range(len(reverse) - 1):
            self.originalWord(reverse[i:len(reverse)], i)  # i=index

        output_list = []


        for i in range(len(word) - 1):
            if self.reverse(word[i:len(word)], i) != []:
                output_list += (self.reverse(word[i:len(word)], i))

        return output_list




def query(filename,id_prefix,last_name_prefix):
     """""
     Functionality of the function: The function paces the id_prefix,last_name_prefix
     to the trie
     [Time complexity]
     Best: O(k + l + nk + nl
     Worst: O(k + l + nk + nl
     [Space complexity]
     Best:T + NM
     Worst: T + NM
     Return: id
     Parameter: filename,id_prefix,last_name_prefix
     Precondition: None
     """

     file = open(filename,'r')
     id_name_array = []
     for line in file:
         line = line.split(" ")
         id_name_array.append([line[1],line[3]])


     last_name_trie = Trie()

     for i in range(len(id_name_array)):
         last_name_trie.addWord(id_name_array[i][1],i)

     last_names = last_name_trie.searchPrefix(last_name_prefix.lower())
     id_trie = Trie()

    #loop through all the indexes of the last_names that start with the prefix given so you only pass the id for those along with the index  so no
    #comparisons needed
     for i in last_names:
         id_trie.addWord(id_name_array[i][0],i)

     id = id_trie.searchPrefix(id_prefix)

     return id



def reverseSubstrings(filename):

    f = open(filename, 'r')
    word = f.readline()
    T2 = Trie2()
    a=T2.addWord2(word)
    return a



if __name__ == "__main__":

    user_input = input("Enter the file name of the query database: ")
    user_input2 = input("Enter the prefix of the identification number: ")
    user_input3 = input("Enter the prefix of the last name: ")

    indexes = query(user_input, user_input2, user_input3)

    print(len(indexes)," record found")

    for i in indexes:
        print("Index number: ", i)




    user = input("Enter the file name for searching reverse substring: ")
    print("---------------------------------------------------------------")

    A =reverseSubstrings(user)

    STR = ""
    for i in A:
        print(i)
        STR += str(i[0]) + '(' + str(i[1]) + '), '
    print(STR)


    print("----------------------------------------------------------------")
    print("program end")






